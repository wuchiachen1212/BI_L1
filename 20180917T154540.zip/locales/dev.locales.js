﻿dev.locales = {
  "en-us": ["en-us", "en-gb"],
  "zh-tw": ["zh-tw"],
  "zh-cn": ["zh-cn"]
};